
import discord
from discord.ext import commands
from discord import app_commands, Interaction, Embed, ButtonStyle
from discord.ui import View, Button, Modal, TextInput
from .premium_security import is_premium

SUBMISSION_CHANNEL_ID = 1407604350125211658  # Verification details submission channel

class VerifyFormModal(Modal, title="Verification Form"):
    """Modal form for user verification"""
    
    def __init__(self, role, panel_channel):
        super().__init__()
        self.role = role
        self.panel_channel = panel_channel

        self.full_name = TextInput(
            label="Full Name", 
            placeholder="Enter your full name (e.g. John Doe)", 
            required=True,
            max_length=100
        )
        self.country_code = TextInput(
            label="Country Code", 
            placeholder="Enter your country code (e.g. +977, +91, +1)", 
            required=True,
            max_length=5
        )
        self.number = TextInput(
            label="Phone Number", 
            placeholder="Enter 10 digit phone number (without country code)", 
            required=True,
            max_length=15
        )
        self.email = TextInput(
            label="Email Address", 
            placeholder="Enter your email address (e.g. john@example.com)", 
            required=True,
            max_length=100
        )
        self.additional_info = TextInput(
            label="Additional Information (Optional)", 
            placeholder="Any additional information you'd like to share", 
            required=False,
            style=discord.TextStyle.paragraph,
            max_length=500
        )

        self.add_item(self.full_name)
        self.add_item(self.country_code)
        self.add_item(self.number)
        self.add_item(self.email)
        self.add_item(self.additional_info)

    async def on_submit(self, interaction: Interaction):
        """Handle form submission and validate data"""
        # Validate phone number
        if not self.number.value.isdigit() or len(self.number.value) < 8 or len(self.number.value) > 15:
            embed = Embed(
                title="❌ Verification Failed",
                description="⚠️ **Invalid phone number! Must be 8-15 digits.**",
                color=0xff0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        # Validate email format (basic check)
        if "@" not in self.email.value or "." not in self.email.value.split("@")[-1]:
            embed = Embed(
                title="❌ Verification Failed",
                description="⚠️ **Invalid email format! Please enter a valid email address.**",
                color=0xff0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        # Validate country code format
        if not self.country_code.value.startswith("+") or not self.country_code.value[1:].isdigit():
            embed = Embed(
                title="❌ Verification Failed",
                description="⚠️ **Invalid country code! Must start with + followed by digits.**",
                color=0xff0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Assign role
            await interaction.user.add_roles(self.role)
            
            # Send details to the global submission channel
            submission_channel = interaction.client.get_channel(SUBMISSION_CHANNEL_ID)
            if submission_channel:
                details_embed = Embed(
                    title="📋 New Verification Submission",
                    description="A user has successfully completed verification.",
                    color=0x00ffff,
                    timestamp=interaction.created_at
                )
                details_embed.set_thumbnail(url=interaction.user.display_avatar.url)
                details_embed.add_field(name="🏠 Server", value=f"{interaction.guild.name}\n`ID: {interaction.guild.id}`", inline=True)
                details_embed.add_field(name="👤 User", value=f"{interaction.user.mention}\n`{interaction.user} (ID: {interaction.user.id})`", inline=True)
                details_embed.add_field(name="🎭 Role Assigned", value=self.role.mention, inline=True)
                details_embed.add_field(name="📛 Full Name", value=f"`{self.full_name.value}`", inline=True)
                details_embed.add_field(name="🌍 Country Code", value=f"`{self.country_code.value}`", inline=True)
                details_embed.add_field(name="📞 Phone Number", value=f"`{self.country_code.value} {self.number.value}`", inline=True)
                details_embed.add_field(name="📧 Email", value=f"`{self.email.value}`", inline=False)
                
                if self.additional_info.value and self.additional_info.value.strip():
                    details_embed.add_field(name="ℹ️ Additional Info", value=f"```{self.additional_info.value[:500]}```", inline=False)
                
                details_embed.set_footer(text="Verification completed at")
                
                try:
                    await submission_channel.send(embed=details_embed)
                except Exception as e:
                    print(f"Failed to send submission to channel: {e}")

            success_embed = Embed(
                title="✅ Verification Complete!",
                description=f"🎉 **Congratulations!** You have been successfully verified and given the role: {self.role.mention}\n\nWelcome to **{interaction.guild.name}**!",
                color=0x00ff00
            )
            await interaction.response.send_message(embed=success_embed, ephemeral=True)
            
        except discord.Forbidden:
            error_embed = Embed(
                title="❌ Verification Failed",
                description="⚠️ **I don't have permission to assign roles! Please contact an administrator.**",
                color=0xff0000
            )
            await interaction.response.send_message(embed=error_embed, ephemeral=True)
        except Exception as e:
            error_embed = Embed(
                title="❌ Verification Failed",
                description=f"⚠️ **An error occurred: {str(e)}**",
                color=0xff0000
            )
            await interaction.response.send_message(embed=error_embed, ephemeral=True)

class PersistentVerifyView(View):
    """Persistent view for verification button that survives bot restarts"""
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Verify", style=ButtonStyle.blurple, custom_id="persistent_verify_btn")
    async def verify_button(self, interaction: Interaction, button: Button):
        # Get the verification setup for this guild
        setup = await self.get_verify_setup(interaction.guild.id)
        if not setup:
            await interaction.response.send_message("Verification setup not found. Please contact an administrator.", ephemeral=True)
            return
        
        role = interaction.guild.get_role(setup["role_id"])
        if not role:
            await interaction.response.send_message("Verification role not found. Please contact an administrator.", ephemeral=True)
            return
        
        # Check if user already has the verification role
        if role in interaction.user.roles:
            embed = Embed(
                title="Already Verified",
                description="ℹ️ **You are already verified in this server!**",
                color=0xff0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        channel = interaction.guild.get_channel(setup["channel_id"])
        await interaction.response.send_modal(VerifyFormModal(role=role, panel_channel=channel))

    async def get_verify_setup(self, guild_id):
        """Get verification setup from database"""
        try:
            from database import db
            doc = db.get_collection('verify_setup').find_one({"guild_id": str(guild_id)})
            if doc:
                return {"channel_id": doc["channel_id"], "role_id": doc["role_id"]}
            return None
        except Exception as e:
            print(f"Error getting verify setup: {e}")
            return None

class EditPanelModal(Modal, title="Edit Verification Panel"):
    """Modal for editing verification panel message"""
    
    def __init__(self, message, channel, role):
        super().__init__()
        self.message = message
        self.channel = channel
        self.role = role
        
        self.title_input = TextInput(
            label="Panel Title",
            placeholder="Enter the panel title",
            default="Verification Panel",
            required=True,
            max_length=256
        )
        
        self.description_input = TextInput(
            label="Panel Description",
            placeholder="Enter the panel description",
            default=f"**\n- Click on Verify button below to get verified \n- Verification Role: {role.mention}\n**",
            required=True,
            style=discord.TextStyle.paragraph,
            max_length=4000
        )
        
        self.color_input = TextInput(
            label="Embed Color (Hex)",
            placeholder="Enter hex color (e.g., 00ffff, ff0000)",
            default="00ffff",
            required=False,
            max_length=6
        )
        
        self.add_item(self.title_input)
        self.add_item(self.description_input)
        self.add_item(self.color_input)

    async def on_submit(self, interaction: Interaction):
        """Handle panel edit submission"""
        try:
            # Parse color
            color_hex = self.color_input.value.strip().replace("#", "")
            if not color_hex:
                color_hex = "00ffff"
            
            try:
                color = int(color_hex, 16)
            except ValueError:
                color = 0x00ffff
            
            # Create new embed
            embed = Embed(
                title=self.title_input.value,
                description=self.description_input.value,
                color=color
            )
            
            # Update the message
            view = PersistentVerifyView()
            await self.message.edit(embed=embed, view=view)
            
            await interaction.response.send_message(
                "✅ **Panel updated successfully!**",
                ephemeral=True
            )
            
        except Exception as e:
            await interaction.response.send_message(
                f"❌ **Failed to update panel:** {str(e)}",
                ephemeral=True
            )

class Verification(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Add persistent view on cog load
        self.bot.add_view(PersistentVerifyView())

    async def get_verify_setup(self, guild_id):
        """Get verification setup from database"""
        try:
            doc = self.bot.db.get_collection('verify_setup').find_one({"guild_id": str(guild_id)})
            if doc:
                return {"channel_id": doc["channel_id"], "role_id": doc["role_id"]}
            return None
        except Exception as e:
            print(f"Error getting verify setup: {e}")
            return None

    async def set_verify_setup(self, guild_id, channel_id, role_id):
        """Set verification setup in database"""
        try:
            self.bot.db.get_collection('verify_setup').update_one(
                {"guild_id": str(guild_id)},
                {"$set": {"channel_id": channel_id, "role_id": role_id}},
                upsert=True
            )
        except Exception as e:
            print(f"Error setting verify setup: {e}")

    @app_commands.command(name="setverify", description="Setup the verification panel channel and role.")
    @app_commands.describe(
        channel="The channel where the verification panel will be sent",
        role="The role that will be given to verified users"
    )
    async def setverify(self, interaction: discord.Interaction, channel: discord.TextChannel, role: discord.Role):
        """Set up verification system for the server"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "You must be an Administrator to use this command.",
                ephemeral=True
            )
            return
            
        await self.set_verify_setup(interaction.guild.id, channel.id, role.id)
        await interaction.response.send_message(
            content=f"✅ Setup complete!\n**Channel:** {channel.mention}\n**Role:** {role.mention}\n\nUse `/sendverifypanel` to send the panel.",
            ephemeral=True
        )

    @app_commands.command(name="sendverifypanel", description="Send the verification panel in the configured channel.")
    async def sendverifypanel(self, interaction: discord.Interaction):
        """Send the verification panel to the configured channel"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "You must be an Administrator to use this command.",
                ephemeral=True
            )
            return
            
        setup = await self.get_verify_setup(interaction.guild.id)
        if not setup:
            await interaction.response.send_message("Verification setup not found. Use `/setverify` first.", ephemeral=True)
            return
        
        channel = interaction.guild.get_channel(setup["channel_id"])
        role = interaction.guild.get_role(setup["role_id"])
        
        if not channel or not role:
            await interaction.response.send_message("Invalid channel or role. Check IDs.", ephemeral=True)
            return
        
        embed = Embed(
            title="Verification Panel",
            description=f"**\n- Click on Verify button below to get verified \n- Verification Role: {role.mention}\n**",
            color=0x00ffff
        )
        
        view = PersistentVerifyView()
        
        try:
            await channel.send(embed=embed, view=view)
            await interaction.response.send_message("Panel sent!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to send messages in that channel!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Failed to send panel: {str(e)}", ephemeral=True)

    @app_commands.command(name="editpanel", description="Edit an existing verification panel message (Premium Feature)")
    @app_commands.describe(message_id="The ID of the verification panel message to edit")
    async def editpanel(self, interaction: discord.Interaction, message_id: str):
        """Edit verification panel message - Premium feature"""
        # Check if premium
        if not is_premium(interaction.guild.id):
            embed = discord.Embed(
                title="<:Unverified:1402342155489640521> Premium Required",
                description="This feature is only available to premium servers. Join our premium server to activate premium",
                color=discord.Color.red()
            )
            view = discord.ui.View()
            view.add_item(discord.ui.Button(label="JOIN", url="https://discord.gg/ERYMCnhWjG", style=discord.ButtonStyle.link))
            await interaction.response.send_message(embed=embed, view=view, ephemeral=False, delete_after=25)
            return
            
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "You must be an Administrator to use this command.",
                ephemeral=True
            )
            return
        
        # Get verification setup
        setup = await self.get_verify_setup(interaction.guild.id)
        if not setup:
            await interaction.response.send_message("Verification setup not found. Use `/setverify` first.", ephemeral=True)
            return
        
        channel = interaction.guild.get_channel(setup["channel_id"])
        role = interaction.guild.get_role(setup["role_id"])
        
        if not channel or not role:
            await interaction.response.send_message("Invalid channel or role. Check setup.", ephemeral=True)
            return
        
        try:
            # Get the message
            message = await channel.fetch_message(int(message_id))
            
            # Check if it's a verification panel (has embed and verify button)
            if not message.embeds or not message.components:
                await interaction.response.send_message("This doesn't appear to be a verification panel message.", ephemeral=True)
                return
            
            # Open edit modal
            await interaction.response.send_modal(EditPanelModal(message, channel, role))
            
        except discord.NotFound:
            await interaction.response.send_message("Message not found in the verification channel.", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("Invalid message ID format.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to access that message.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Failed to edit panel: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Verification(bot))
